# API Database Game

Proyek ini adalah API untuk mengelola database game menggunakan PHP dan MySQL. API ini mendukung operasi CRUD (Create, Read, Update, Delete) dan dapat diuji menggunakan Postman.

## Daftar Isi
- [Fitur](#fitur)
- [Instalasi](#instalasi)
- [Penggunaan](#penggunaan)
- [Endpoint API](#endpoint-api)
- [Keamanan](#keamanan)
- [Lisensi](#lisensi)
- [Dokumentasi Postman](#dokumentasi-postman)

## Fitur
- Membuat game baru
- Mengambil semua game atau game tertentu berdasarkan ID
- Memperbarui data game yang ada
- Menghapus game dari database
- Respon dalam format JSON untuk semua operasi
- Autentikasi menggunakan JWT
- Validasi input untuk mencegah SQL Injection

## Instalasi
1. Clone repositori:
   ```bash
   git clone https://github.com/MahendraNabiel/MahendraCode.git
